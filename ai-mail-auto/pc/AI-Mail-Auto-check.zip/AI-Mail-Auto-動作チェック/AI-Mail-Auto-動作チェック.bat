@echo off
chcp 65001 >nul
rem ASCII only on purpose. Runs the single .ps1 next to this file.
for %%F in ("%~dp0*.ps1") do powershell -NoProfile -ExecutionPolicy Bypass -File "%%F"
