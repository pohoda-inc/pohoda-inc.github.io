﻿# AI Mail Auto 動作チェック（Windows）。メールは一切読みません・送りません。使うのは架空のメールだけ。
# 試験用: 環境変数 AIMAIL_CHECK_MODEL に別のモデル名を入れると、そのモデルで流れだけを確かめられます。
$CheckVersion = '1.0.0'
$Model = if ($env:AIMAIL_CHECK_MODEL) { $env:AIMAIL_CHECK_MODEL } else { 'gemma4:e4b' }
$Port = 11439
$TimeoutSec = 110   # 製品の下書きの待ち時間の上限（box/server.mjs の ollamaTimeoutMs = 110000）と同じ
$FastSec = 10       # Jakob Nielsen「Response Times: The 3 Important Limits」(1993) の 10 秒
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Prompts = Join-Path $Here 'prompts.json'
$Desktop = [Environment]::GetFolderPath('Desktop')
$Report = Join-Path $Desktop 'AI-Mail-Auto-動作チェックの結果.txt'
$Work = $null
$Server = $null
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Say($t) { Write-Host $t }

function Stop-Everything {
    if ($script:Server) { try { & taskkill.exe /PID $script:Server.Id /T /F 2>&1 | Out-Null } catch {} }
    if ($script:Work) {
        try { Get-Process | Where-Object { $_.Path -and $_.Path.StartsWith($script:Work) } | ForEach-Object { try { $_.Kill() } catch {} } } catch {}
        Start-Sleep -Seconds 2
        for ($i = 0; $i -lt 8 -and (Test-Path $script:Work); $i++) {
            try { Remove-Item -Recurse -Force -LiteralPath $script:Work -ErrorAction Stop } catch { Start-Sleep -Seconds 2 }
        }
        if (Test-Path $script:Work) { Say ''; Say "後片付けが一部できませんでした。次のフォルダを手で削除してください: $($script:Work)" }
        else { Say ''; Say '後片付けをしました（ダウンロードしたものをすべて消しました）。' }
    }
}

function Get-Median($xs) {
    $s = @($xs | Sort-Object); $n = $s.Count
    if ($n % 2 -eq 1) { return [double]$s[($n - 1) / 2] }
    return ([double]$s[$n / 2 - 1] + [double]$s[$n / 2]) / 2
}

function Get-VramMap {
    # 専用メモリ（VRAM）。AdapterRAM は 4GB で頭打ちになるため、レジストリの値を使う
    $map = @{}
    $cls = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
    try {
        Get-ChildItem $cls -ErrorAction Stop | Where-Object { $_.PSChildName -match '^\d{4}$' } | ForEach-Object {
            $p = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
            $v = $p.'HardwareInformation.qwMemorySize'
            if ($v -is [byte[]]) { $v = [BitConverter]::ToUInt64($v, 0) }
            if ($p.DriverDesc -and $v) { $map[[string]$p.DriverDesc] = [double]$v }
        }
    } catch {}
    return $map
}

function Write-Report($verdict, $cls, $drf, $tps, $note) {
    $lines = @(
        'AI Mail Auto 動作チェックの結果',
        "チェックのバージョン: $CheckVersion",
        "日付: $(Get-Date -Format 'yyyy-MM-dd HH:mm')",
        '',
        "判定: $verdict",
        "分類 1 通: $cls",
        "下書き 1 通: $drf",
        "書く速さ: $tps"
    )
    if ($note) { $lines += @('', $note) }
    $lines += @('', '--- この PC ---', $script:PcInfo, '',
        'このファイルにはお名前・メール・PC の名前・製造番号などは入っていません。',
        'ご購入のご相談のときは、このファイルを pohoda.inc@gmail.com へお送りください。')
    [IO.File]::WriteAllLines($Report, $lines, (New-Object Text.UTF8Encoding($true)))
    Say ''; Say "結果を保存しました: $Report"
    Say 'ご購入のご相談のときは、このファイルを pohoda.inc@gmail.com へお送りください。'
}

function Main {
    Say '=================================================='
    Say " AI Mail Auto 動作チェック（バージョン $CheckVersion）"
    Say '=================================================='
    Say ''
    Say 'この PC で AI が十分な速さで動くかを調べます。'
    Say 'メールは読みません。送りません。使うのは架空のメールだけです。'
    Say ''
    Say '【ステップ A】この PC の簡易チェック（ダウンロードなし・約 1 分）'
    Say ''

    $os = Get-CimInstance Win32_OperatingSystem
    $osName = "$($os.Caption) （バージョン $($os.Version)）"
    $cpu = (Get-CimInstance Win32_Processor | Select-Object -First 1).Name.Trim()
    $arch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    $memBytes = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum
    if (-not $memBytes) { $memBytes = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory }
    $memGB = [int][math]::Round($memBytes / 1GB)
    $vram = Get-VramMap
    $gpus = @()
    foreach ($g in @(Get-CimInstance Win32_VideoController)) {
        $v = $vram[[string]$g.Name]
        if (-not $v -and $g.AdapterRAM) { $v = [double]$g.AdapterRAM }
        $gpus += if ($v) { "$($g.Name)（専用メモリ 約 $([math]::Round($v / 1GB, 1)) GB）" } else { "$($g.Name)（専用メモリ 不明）" }
    }
    if (-not $gpus) { $gpus = @('不明') }
    try {
        $di = New-Object IO.DriveInfo($env:USERPROFILE.Substring(0, 1))
        $freeGB = [int][math]::Floor($di.AvailableFreeSpace / 1GB)
    } catch { $freeGB = -1 }

    Say "OS       : $osName"
    Say "CPU      : $cpu（$arch）"
    Say "メモリ   : $memGB GB"
    foreach ($g in $gpus) { Say "GPU      : $g" }
    Say "空き容量 : $freeGB GB（ホームフォルダのあるドライブ）"
    Say ''
    $script:PcInfo = "OS: $osName`r`nCPU: $cpu（$arch）`r`nメモリ: $memGB GB`r`nGPU: $($gpus -join ' / ')`r`n空き容量: $freeGB GB"

    function Stop-Early($verdict, $reason) {
        Say "判定: $verdict"; Say $reason
        Write-Report $verdict '測っていません' '測っていません' '測っていません' $reason
    }
    if ($arch -ne 'AMD64' -and $arch -ne 'ARM64') { Stop-Early '対象外（Apple シリコンの Mac か Windows が対象）' "この PC の種類（$arch）は対象外です。"; return }
    if ($memGB -lt 16 -and -not $env:AIMAIL_CHECK_MODEL) { Stop-Early '足りません' "メモリが 16 GB 未満です（この PC は $memGB GB）。AI の部品が 9.5 GB ほど使うため、16 GB 以上が必要です。"; return }
    if ($freeGB -ge 0 -and $freeGB -lt 15) { Stop-Early '空きが足りません' "空き容量が 15 GB 未満です（この PC は $freeGB GB）。AI の部品の保管に約 11 GB 使います。"; return }

    Say '簡易チェックは通りました。次は実際に動かして速さを測ります。'
    Say ''
    Say '【ステップ B】実測（AI を実際に動かして測ります）'
    Say ''
    $dl = if ($arch -eq 'ARM64') { '約 0.4 GB' } else { '約 1.6 GB' }
    Say "  ・無料の AI ソフト Ollama（$dl）と AI の部品（約 9.5 GB）を、ollama.com からだけダウンロードします。"
    Say '  ・時間は、回線の速さによって 10〜30 分ほどかかります。'
    Say '  ・メールの中身は読みません。送りません。使うのは架空のメールだけです。'
    Say '  ・すでに Ollama が入っていても、触りません（別の場所・別の出入り口で動かします）。'
    Say '  ・終わったら、ダウンロードしたものはすべて消します。'
    Say ''
    $ans = Read-Host 'ステップ B を始めてよろしいですか？（はい / y で開始、それ以外で終了）'
    if ($ans -notin @('はい', 'y', 'Y', 'yes', 'YES')) {
        Say ''; Say 'ここで終了します。ステップ A の結果だけ保存します。'
        Write-Report '簡易チェックのみ（実測はしていません）' '測っていません' '測っていません' '測っていません' 'メモリ・空き容量は条件を満たしています。'
        return
    }
    if (-not (Test-Path $Prompts)) { Say 'prompts.json が見つかりません。ZIP を展開したフォルダのまま実行してください。'; return }

    $script:Work = Join-Path $env:TEMP ('aimail-check-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Path $script:Work | Out-Null
    $zipName = if ($arch -eq 'ARM64') { 'ollama-windows-arm64.zip' } else { 'ollama-windows-amd64.zip' }
    $zip = Join-Path $script:Work 'ollama.zip'

    Say ''; Say '1/5 Ollama をダウンロードしています…'
    $url = "https://ollama.com/download/$zipName"
    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) { & curl.exe -fL --progress-bar -o $zip $url; $ok = ($LASTEXITCODE -eq 0) }
    else { $ProgressPreference = 'SilentlyContinue'; try { Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing; $ok = $true } catch { $ok = $false } }
    if (-not $ok) { Say 'ダウンロードに失敗しました。ネットワークをご確認ください。'; return }
    $bin = Join-Path $script:Work 'bin'
    New-Item -ItemType Directory -Path $bin | Out-Null
    Say '  展開しています（数分かかることがあります）…'
    $tar = Get-Command tar.exe -ErrorAction SilentlyContinue
    if ($tar) { & tar.exe -xf $zip -C $bin } else { $ProgressPreference = 'SilentlyContinue'; Expand-Archive -LiteralPath $zip -DestinationPath $bin -Force }
    Remove-Item -Force $zip -ErrorAction SilentlyContinue
    $exe = (Get-ChildItem -Path $bin -Recurse -Filter ollama.exe | Select-Object -First 1).FullName
    if (-not $exe) { Say 'Ollama を展開できませんでした。'; return }

    Say '2/5 AI ソフトを起動しています…'
    $env:OLLAMA_HOST = "127.0.0.1:$Port"
    $env:OLLAMA_MODELS = Join-Path $script:Work 'models'
    $script:Server = Start-Process -FilePath $exe -ArgumentList 'serve' -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $script:Work 'serve.log') -RedirectStandardError (Join-Path $script:Work 'serve.err')
    $up = $false
    for ($i = 0; $i -lt 60; $i++) {
        try { Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/version" -TimeoutSec 2 | Out-Null; $up = $true; break } catch { Start-Sleep -Seconds 1 }
        if ($script:Server.HasExited) { break }
    }
    if (-not $up) { Say 'AI ソフトを起動できませんでした。'; return }

    Say '3/5 AI の部品（約 9.5 GB）をダウンロードしています。しばらくかかります…'
    & $exe pull $Model
    if ($LASTEXITCODE -ne 0) { Say 'AI の部品のダウンロードに失敗しました。'; return }

    $utf8 = New-Object Text.UTF8Encoding($false)
    $bodies = @()
    foreach ($line in [IO.File]::ReadAllLines($Prompts, $utf8)) {
        if ($line.StartsWith('{"kind"')) {
            $b = $line -replace '^\{"kind":"[a-z]*","label":"[^"]*","body":', ''
            $b = $b.TrimEnd(',')
            $b = $b.Substring(0, $b.Length - 1)
            $bodies += $b.Replace('__MODEL__', $Model)
        }
    }
    function Ask($i, $timeout) {
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $r = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/chat" -Method Post -ContentType 'application/json' -Body ($utf8.GetBytes($bodies[$i])) -TimeoutSec $timeout
        $sw.Stop()
        return @{ Sec = $sw.Elapsed.TotalSeconds; R = $r }
    }

    Say '4/5 ウォームアップ（AI をメモリに読み込みます・測りません）…'
    try { Ask 0 900 | Out-Null } catch {}

    Say '5/5 実測しています…'
    $cls = @(); $drf = @(); $tok = 0.0; $ns = 0.0; $problem = $null
    for ($i = 0; $i -lt 4; $i++) {
        try {
            $a = Ask $i $TimeoutSec
            if (-not $a.R.done -or $a.R.done_reason -eq 'length') { throw 'incomplete' }
        } catch { $problem = "$($i + 1) 通目の依頼が終わりませんでした（$TimeoutSec 秒を超えたか、エラーでした）。"; break }
        Say ("  {0}/4 … {1:N1} 秒" -f ($i + 1), $a.Sec)
        if ($i -lt 2) { $cls += $a.Sec } else { $drf += $a.Sec; $tok += [double]$a.R.eval_count; $ns += [double]$a.R.eval_duration }
    }
    if ($problem) {
        $why = "$problem 製品でも $TimeoutSec 秒を超えるとあきらめるため、この機械では実用になりません。"
        Say ''; Say '判定: この機械では難しいです'; Say $why
        Write-Report 'この機械では難しいです' '失敗' '失敗' '失敗' $why
        return
    }
    $clsMed = Get-Median $cls; $drfMed = Get-Median $drf
    $tps = if ($ns -gt 0) { '{0:N1} トークン/秒' -f ($tok / ($ns / 1e9)) } else { '不明' }
    $verdict = if ($drfMed -le $FastSec) { '快適に使えます' } else { '使えますが、手で頼む下書きは待ち時間が長めです' }
    $clsS = '{0:N1} 秒（中央値）' -f $clsMed; $drfS = '{0:N1} 秒（中央値）' -f $drfMed
    $note = "判定の基準: 「AI で下書き」ボタンを押して待つ下書きが $FastSec 秒以内なら「快適」です。人が作業に集中し続けられる待ち時間の限界が 10 秒、という Jakob Nielsen の研究（Response Times: The 3 Important Limits, 1993）によります。$TimeoutSec 秒を超えると、製品が自動でやめる上限のため「難しい」です。`r`n新しく届いたメールの分類と下書きは、届いたときに裏で進むため、待つことはありません。待つのは、ご自分で「AI で下書き」を押したときだけです。"
    Say ''; Say '=================================================='
    Say " 判定: $verdict"
    Say '=================================================='
    Say "分類 1 通    : $clsS"
    Say "下書き 1 通  : $drfS"
    Say "書く速さ     : $tps"
    Say ''; Say $note
    Write-Report $verdict $clsS $drfS $tps $note
}

try { Main }
catch { Say ''; Say "予期しないエラーが起きました: $($_.Exception.Message)" }
finally {
    Stop-Everything
    Say ''
    Read-Host 'Enter キーを押すと閉じます' | Out-Null
}
