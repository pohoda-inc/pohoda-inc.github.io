#!/bin/bash
# AI Mail Auto 動作チェック（Mac）。メールは一切読みません・送りません。使うのは架空のメールだけ。
# 試験用: AIMAIL_CHECK_MODEL に別のモデル名を入れると、そのモデルで流れだけを確かめられます。
CHECK_VERSION="1.0.0"
MODEL="${AIMAIL_CHECK_MODEL:-gemma4:e4b}"
PORT=11439
TIMEOUT=110   # 製品の下書きの待ち時間の上限（box/server.mjs の ollamaTimeoutMs = 110000）と同じ
FAST_SEC=10   # Jakob Nielsen「Response Times: The 3 Important Limits」(1993) の 10 秒
OLLAMA_URL="https://ollama.com/download/ollama-darwin.tgz"
HERE="$(cd "$(dirname "$0")" && pwd)"
PROMPTS="$HERE/prompts.json"
WORK=""; SERVER_PID=""

say() { printf '%s\n' "$*"; }
cleanup() {
  trap - EXIT
  if [ -n "$SERVER_PID" ]; then kill "$SERVER_PID" 2>/dev/null; fi
  if [ -n "$WORK" ] && [ -d "$WORK" ]; then
    pkill -f "$WORK/" 2>/dev/null
    sleep 1
    rm -rf "$WORK"
    say ""; say "後片付けをしました（ダウンロードしたものをすべて消しました）。"
  fi
}
trap cleanup EXIT
trap 'say ""; say "中止しました。"; exit 130' INT TERM HUP
pause_end() { say ""; printf 'Enter キーを押すと閉じます。'; read -r _; }

say "=================================================="
say " AI Mail Auto 動作チェック（バージョン $CHECK_VERSION）"
say "=================================================="
say ""
say "この PC で AI が十分な速さで動くかを調べます。"
say "メールは読みません。送りません。使うのは架空のメールだけです。"
say ""
say "【ステップ A】この PC の簡易チェック（ダウンロードなし・約 1 分）"
say ""

OS_NAME="$(sw_vers -productName 2>/dev/null) $(sw_vers -productVersion 2>/dev/null)"
ARCH="$(uname -m)"
CPU="$(sysctl -n machdep.cpu.brand_string 2>/dev/null)"
ARM="$(sysctl -n hw.optional.arm64 2>/dev/null)"
[ "$ARM" = "1" ] && APPLE_SI=1 || APPLE_SI=0
[ "$APPLE_SI" = 1 ] && [ -z "$CPU" ] && CPU="Apple シリコン"
MEM_BYTES="$(sysctl -n hw.memsize 2>/dev/null)"
MEM_GB=$(( (MEM_BYTES + 536870912) / 1073741824 ))
GPU="$(system_profiler SPDisplaysDataType 2>/dev/null | sed -n 's/^ *Chipset Model: *//p' | paste -sd ',' - | sed 's/,/、/g')"
[ -z "$GPU" ] && GPU="不明"
if [ "$APPLE_SI" = 1 ]; then VRAM="（Apple シリコンはメモリを CPU と GPU で共有します：$MEM_GB GB）"; else VRAM="不明"; fi
FREE_KB="$(df -k "$HOME" | awk 'NR==2{print $4}')"
FREE_GB=$(( FREE_KB / 1048576 ))

say "OS         : $OS_NAME"
say "CPU        : $CPU（$ARCH）"
say "メモリ     : $MEM_GB GB"
say "GPU        : $GPU $([ "$APPLE_SI" = 1 ] && echo "$VRAM")"
say "空き容量   : $FREE_GB GB（ホームフォルダのあるドライブ）"
say ""

PC_INFO="OS: $OS_NAME
CPU: $CPU（$ARCH）
メモリ: $MEM_GB GB
GPU: $GPU $([ "$APPLE_SI" = 1 ] && echo "$VRAM")
空き容量: $FREE_GB GB"

REPORT="$HOME/Desktop/AI-Mail-Auto-動作チェックの結果.txt"
write_report() { # $1=判定 $2=分類 $3=下書き $4=tok/s $5=補足
  {
    echo "AI Mail Auto 動作チェックの結果"
    echo "チェックのバージョン: $CHECK_VERSION"
    echo "日付: $(date '+%Y-%m-%d %H:%M')"
    echo ""
    echo "判定: $1"
    echo "分類 1 通: $2"
    echo "下書き 1 通: $3"
    echo "書く速さ: $4"
    [ -n "$5" ] && { echo ""; echo "$5"; }
    echo ""
    echo "--- この PC ---"
    echo "$PC_INFO"
    echo ""
    echo "このファイルにはお名前・メール・PC の名前・製造番号などは入っていません。"
    echo "ご購入のご相談のときは、このファイルを pohoda.inc@gmail.com へお送りください。"
  } > "$REPORT"
  say ""; say "結果を保存しました: $REPORT"
  say "ご購入のご相談のときは、このファイルを pohoda.inc@gmail.com へお送りください。"
}
stop_early() { # $1=判定文 $2=理由
  say "判定: $1"; say "$2"
  write_report "$1" "測っていません" "測っていません" "測っていません" "$2"
  pause_end; exit 0
}

if [ "$APPLE_SI" != 1 ]; then stop_early "対象外（Apple シリコンの Mac か Windows が対象）" "この Mac は Intel のため、AI Mail Auto の AI は使えません。"; fi
if [ "$MEM_GB" -lt 16 ]; then stop_early "足りません" "メモリが 16 GB 未満です（この PC は $MEM_GB GB）。AI の部品が 9.5 GB ほど使うため、16 GB 以上が必要です。"; fi
if [ "$FREE_GB" -lt 15 ]; then stop_early "空きが足りません" "空き容量が 15 GB 未満です（この PC は $FREE_GB GB）。AI の部品の保管に約 11 GB 使います。"; fi

say "簡易チェックは通りました。次は実際に動かして速さを測ります。"
say ""
say "【ステップ B】実測（AI を実際に動かして測ります）"
say ""
say "  ・無料の AI ソフト Ollama（約 0.2 GB）と AI の部品（約 9.5 GB）を、ollama.com からだけダウンロードします。"
say "  ・時間は、回線の速さによって 10〜30 分ほどかかります。"
say "  ・メールの中身は読みません。送りません。使うのは架空のメールだけです。"
say "  ・すでに Ollama が入っていても、触りません（別の場所・別の出入り口で動かします）。"
say "  ・終わったら、ダウンロードしたものはすべて消します。"
say ""
printf 'ステップ B を始めてよろしいですか？（はい / y で開始、それ以外で終了）: '
read -r ANS
case "$ANS" in はい|y|Y|yes|YES) ;; *) say ""; say "ここで終了します。ステップ A の結果だけ保存します。"; write_report "簡易チェックのみ（実測はしていません）" "測っていません" "測っていません" "測っていません" "メモリ・空き容量は条件を満たしています。"; pause_end; exit 0;; esac

[ -f "$PROMPTS" ] || { say "prompts.json が見つかりません。ZIP を展開したフォルダのまま実行してください。"; pause_end; exit 1; }
WORK="$(mktemp -d "${TMPDIR:-/tmp}/aimail-check.XXXXXX")" || { say "作業用フォルダを作れませんでした。"; pause_end; exit 1; }
chmod 700 "$WORK"

fail() { say ""; say "判定: この機械では難しいです"; say "$1"; write_report "この機械では難しいです" "失敗" "失敗" "失敗" "$1"; pause_end; exit 0; }

say ""; say "1/5 Ollama をダウンロードしています…"
curl -fL --progress-bar -o "$WORK/ollama.tgz" "$OLLAMA_URL" || { say "ダウンロードに失敗しました。ネットワークをご確認ください。"; pause_end; exit 1; }
mkdir "$WORK/bin" && tar xzf "$WORK/ollama.tgz" -C "$WORK/bin" && rm -f "$WORK/ollama.tgz"
chmod +x "$WORK/bin/ollama"

say "2/5 AI ソフトを起動しています…"
export OLLAMA_HOST="127.0.0.1:$PORT"
export OLLAMA_MODELS="$WORK/models"
"$WORK/bin/ollama" serve > "$WORK/serve.log" 2>&1 &
SERVER_PID=$!
UP=0; i=0
while [ $i -lt 60 ]; do
  curl -s -m 2 "http://127.0.0.1:$PORT/api/version" >/dev/null 2>&1 && { UP=1; break; }
  kill -0 "$SERVER_PID" 2>/dev/null || break
  sleep 1; i=$((i+1))
done
[ "$UP" = 1 ] || { say "AI ソフトを起動できませんでした。"; pause_end; exit 1; }

say "3/5 AI の部品（約 9.5 GB）をダウンロードしています。しばらくかかります…"
"$WORK/bin/ollama" pull "$MODEL" || { say "AI の部品のダウンロードに失敗しました。"; pause_end; exit 1; }

BODIES="$WORK/bodies"; mkdir "$BODIES"
n=0
grep '^{"kind"' "$PROMPTS" | while IFS= read -r line; do
  n=$((n+1))
  printf '%s\n' "$line" | sed 's/^{"kind":"[a-z]*","label":"[^"]*","body"://; s/,$//; s/}$//; s#__MODEL__#'"$MODEL"'#' > "$BODIES/$n.json"
done
ask() { # $1=番号 → $WORK/r.json に結果、"HTTPコード 秒" を表示
  curl -s -m "$TIMEOUT" -o "$WORK/r.json" -w '%{http_code} %{time_total}' -H 'Content-Type: application/json' --data-binary "@$BODIES/$1.json" "http://127.0.0.1:$PORT/api/chat"
}

say "4/5 ウォームアップ（AI をメモリに読み込みます・測りません）…"
curl -s -m 900 -o /dev/null -H 'Content-Type: application/json' --data-binary "@$BODIES/1.json" "http://127.0.0.1:$PORT/api/chat"

say "5/5 実測しています…"
CLS=""; DRF=""; EVAL_TOK=0; EVAL_NS=0; PROBLEM=""
for n in 1 2 3 4; do
  OUT="$(ask $n)"; CODE="${OUT% *}"; SEC="${OUT#* }"
  if [ "$CODE" != "200" ] || ! grep -q '"done":true' "$WORK/r.json" || grep -q '"done_reason":"length"' "$WORK/r.json"; then
    PROBLEM="${n} 通目の依頼が終わりませんでした（${TIMEOUT} 秒を超えたか、エラーでした）。"; break
  fi
  say "  $n/4 … $(awk -v x="$SEC" 'BEGIN{printf "%.1f", x}') 秒"
  if [ $n -le 2 ]; then CLS="$CLS $SEC"; else
    DRF="$DRF $SEC"
    T="$(grep -o '"eval_count":[0-9]*' "$WORK/r.json" | tail -1 | cut -d: -f2)"
    D="$(grep -o '"eval_duration":[0-9]*' "$WORK/r.json" | tail -1 | cut -d: -f2)"
    EVAL_TOK=$((EVAL_TOK + ${T:-0})); EVAL_NS=$((EVAL_NS + ${D:-0}))
  fi
done
[ -z "$PROBLEM" ] || fail "$PROBLEM 製品でも ${TIMEOUT} 秒を超えるとあきらめるため、この機械では実用になりません。"

median() { printf '%s\n' "$@" | sort -n | awk '{a[NR]=$1} END{if(NR%2)print a[(NR+1)/2]; else print (a[NR/2]+a[NR/2+1])/2}'; }
CLS_MED="$(median $CLS)"; DRF_MED="$(median $DRF)"
TPS="$(awk -v t="$EVAL_TOK" -v d="$EVAL_NS" 'BEGIN{ if(d>0) printf "%.1f", t/(d/1e9); else print "不明" }')"
CLS_S="$(awk -v x="$CLS_MED" 'BEGIN{printf "%.1f 秒（中央値）", x}')"
DRF_S="$(awk -v x="$DRF_MED" 'BEGIN{printf "%.1f 秒（中央値）", x}')"
if awk -v x="$DRF_MED" -v l="$FAST_SEC" 'BEGIN{exit !(x<=l)}'; then VERDICT="快適に使えます"; else VERDICT="使えますが、手で頼む下書きは待ち時間が長めです"; fi

NOTE="判定の基準: 「AI で下書き」ボタンを押して待つ下書きが ${FAST_SEC} 秒以内なら「快適」です。人が作業に集中し続けられる待ち時間の限界が 10 秒、という Jakob Nielsen の研究（Response Times: The 3 Important Limits, 1993）によります。${TIMEOUT} 秒を超えると、製品が自動でやめる上限のため「難しい」です。
新しく届いたメールの分類と下書きは、届いたときに裏で進むため、待つことはありません。待つのは、ご自分で「AI で下書き」を押したときだけです。"
say ""; say "=================================================="
say " 判定: $VERDICT"
say "=================================================="
say "分類 1 通    : $CLS_S"
say "下書き 1 通  : $DRF_S"
say "書く速さ     : $TPS トークン/秒"
say ""; say "$NOTE"
write_report "$VERDICT" "$CLS_S" "$DRF_S" "$TPS トークン/秒" "$NOTE"
pause_end
